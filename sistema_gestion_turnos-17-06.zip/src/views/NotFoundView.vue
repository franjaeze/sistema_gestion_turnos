<template>
  <div>
    <h2>Error 404, ruta no encontrada</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>