# about the Project

This project was made in order to practice the new technologies we learnd in "Programacion en Nuevas Tecnologias 2" subject, from ORT institute. The technologies we had to try were: Vue js, Pinia, Ionic, Axios. Collaborations Mateo Bellomo, Camila Szeko and Paola Quiñonez.

The project istelf its a booking website for a Beauty spa


## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
