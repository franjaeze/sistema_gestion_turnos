<template>
  <ion-page>
    <ion-content>
                      
    <h2 class=" ">2023-TP2-BE-21E-SistemaDeGestionDeTurnos- "Beauty Spa"

Este es el sistema de gestion de turnos del centro de estética Beauty Spa del grupo 1</h2>
  </ion-content></ion-page>
</template>

<script>
import {IonPage,IonContent} from '@ionic/vue'
export default {
  components: {IonPage, IonContent}
}
</script>
